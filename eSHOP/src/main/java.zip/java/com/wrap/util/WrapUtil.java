package com.wrap.util;

import java.lang.reflect.Field;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.wrap.daoimpl.WrapCategoryDaoImpl;
import com.wrap.daoimpl.WrapColumnDaoImpl;
import com.wrap.daoimpl.WrapProductDaoImpl;
import com.wrap.daoimpl.WrapTabDaoImpl;
import com.wrap.daoimpl.WrapUserAddressDaoImpl;
import com.wrap.daoimpl.WrapUserDaoImpl;
import com.wrap.imodal.WrapProductSize;
import com.wrap.modal.WrapCart;
import com.wrap.modal.WrapCartItem;
import com.wrap.modal.WrapCategory;
import com.wrap.modal.WrapColumn;
import com.wrap.modal.WrapCustomer;
import com.wrap.modal.WrapCustomerManagement;
import com.wrap.modal.WrapNavCat;
import com.wrap.modal.WrapNavCol;
import com.wrap.modal.WrapNavModal;
import com.wrap.modal.WrapNavTab;
import com.wrap.modal.WrapOrder;
import com.wrap.modal.WrapProduct;
import com.wrap.modal.WrapTab;
import com.wrap.modal.WrapUser;
import com.wrap.modal.WrapUserAddress;
import com.wrap.modal.WrapUserCard;

public class WrapUtil {

	private DataSource dataSource;

	@Autowired
	WrapNavModal wrapNavModal;

	@Autowired
	WrapTabDaoImpl wrapTabDaoImpl;

	@Autowired
	WrapColumnDaoImpl wrapColumnDaoImpl;

	@Autowired
	WrapCategoryDaoImpl wrapCategoryDaoImpl;

	@Autowired
	WrapProductDaoImpl wrapProductDaoImpl;

	@Autowired
	WrapUserDaoImpl wrapUserDaoImpl;

	@Autowired
	WrapUserAddressDaoImpl wrapUserAddressDaoImpl;

	public void setDataSource(DataSource dataSource) {
		this.dataSource = dataSource;
	}

	public JdbcTemplate getJdbcTemplate() {
		return new JdbcTemplate(dataSource);
	}

	public WrapNavModal getWrapNavModal() {
		WrapNavModal navModal = new WrapNavModal();
		List<WrapNavTab> wrapNavTabList = new ArrayList<WrapNavTab>();
		for (WrapTab wrapTab : wrapTabDaoImpl.getWrapTabs()) {
			WrapNavTab navTab = new WrapNavTab();
			navTab.setWrapTab(wrapTab);
			navTab.setImage1Path(getNavImage1(wrapTab.getWrapTabId()));
			navTab.setImage2Path(getNavImage2(wrapTab.getWrapTabId()));
			List<WrapNavCol> wrapNavColList = new ArrayList<WrapNavCol>();
			for (WrapColumn wrapColumn : wrapColumnDaoImpl
					.getWrapColumnListByTabId(wrapTab.getWrapTabId())) {
				WrapNavCol navCol = new WrapNavCol();
				navCol.setWrapColumn(wrapColumn);
				List<WrapNavCat> wrapNavCatList = new ArrayList<WrapNavCat>();
				for (WrapCategory wrapCategory : wrapCategoryDaoImpl
						.getWrapCategoriesByTabByColIds(
								wrapColumn.getWrapTabId(),
								wrapColumn.getWrapColId())) {
					WrapNavCat navCat = new WrapNavCat();
					navCat.setWrapCategory(wrapCategory);
					wrapNavCatList.add(navCat);
				}
				navCol.setWrapNavCatList(wrapNavCatList);
				wrapNavColList.add(navCol);
			}
			navTab.setWrapNavColList(wrapNavColList);
			wrapNavTabList.add(navTab);
		}
		navModal.setWrapNavTabList(wrapNavTabList);
		return navModal;
	}

	public String getNavImage1(String tabId) {
		if (tabId.equals("WRAPTAB_1")) {
			return "resources/images/wrapit-tab-structure/Books & More/Books/Academics/a-short-history-of-nearly-everything-original-imae39.jpeg";
		} else if (tabId.equals("WRAPTAB_2")) {
			return "resources/images/wrapit-tab-structure/Featured/Laptops/Apple/apple-macbook-air-ultrabook-original-imae6qyjz3j9bx7y.jpeg";
		} else if (tabId.equals("WRAPTAB_3")) {
			return "resources/images/wrapit-tab-structure/Home & Furniture/Furniture/Beds/397-king-mango-wood-dream-furniture-india-grey-grey-original-imaegtg4qqbpacyx.jpeg";
		} else if (tabId.equals("WRAPTAB_4")) {
			return "resources/images/wrapit-tab-structure/Trending/Clothing/Jeans/268106797-grey-ms-newport-32-original-imaehmzn6dhzfmam.jpeg";
		}
		return "";
	}

	public String getNavImage2(String tabId) {
		if (tabId.equals("WRAPTAB_1")) {
			return "resources/images/wrapit-tab-structure/Books & More/Books/Children/the-bro-code-original-imadzmykjvgmcarn.jpeg";
		} else if (tabId.equals("WRAPTAB_2")) {
			return "resources/images/wrapit-tab-structure/Featured/TV/Full HD/sony-bravia-klv-22p413d-original-imaed8jtgujdkq4g.jpeg";
		} else if (tabId.equals("WRAPTAB_3")) {
			return "resources/images/wrapit-tab-structure/Home & Furniture/HomeDecor/Wall Decals/wt-6005-aquire-bedroom-romantic-rose-flowers-120-75cm-original-imae4g4mxbyzbszz.jpeg";
		} else if (tabId.equals("WRAPTAB_4")) {
			return "resources/images/wrapit-tab-structure/Trending/Footwear/Casual Shoes/green-white-goldmt-gazelle-adidas-originals-9-original-imaemawhmhvtzkhf.jpeg";
		}
		return "";
	}

	public List<WrapProduct> getWrapProducts(String argTabId, String argColId,
			String argCatId) {
		List<WrapProduct> wrapProductList = wrapProductDaoImpl
				.getWrapProductsByTabByColByCatIds(argTabId, argColId, argCatId);
		return wrapProductList;
	}

	public WrapProduct getWrapProducts(String argTabId, String argColId,
			String argCatId, String argProdId) {
		WrapProduct wrapProduct = wrapProductDaoImpl
				.getWrapProductsByTabByColByCatByProdIds(argTabId, argColId,
						argCatId, argProdId);
		return wrapProduct;
	}

	public double round(double value, int places) {
		if (places < 0)
			throw new IllegalArgumentException();

		BigDecimal bd = new BigDecimal(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}

	public List<WrapProduct> getAlsoBaughtTogetherWrapProductsByTabByColIds(
			String argTabId, String argColId, String argCatId, int rowCount) {
		List<WrapProduct> wrapProductsList = wrapProductDaoImpl
				.getAlsoBaughtTogetherWrapProductsByTabByColIds(argTabId,
						argColId, argCatId, rowCount);

		return wrapProductsList;
	}

	public WrapCartItem castWrapProuctToWrapCartItem(
			WrapProduct argWrapProduct, int argItemCount, String argSize,
			String argColor) {
		WrapCartItem cartItem = new WrapCartItem();
		cartItem.setItemTabId(argWrapProduct.getWrapTabId());
		cartItem.setItemColId(argWrapProduct.getWrapColId());
		cartItem.setItemCatId(argWrapProduct.getWrapCatId());
		cartItem.setItemId(argWrapProduct.getWrapProdId());
		cartItem.setItemCount(argItemCount);
		cartItem.setItemName(argWrapProduct.getWrapProdName());
		cartItem.setItemDescription(argWrapProduct.getWrapProdDescription());
		cartItem.setItemSize(WrapProductSize.valueOf(argSize));
		// cartItem.setItemColor(WrapProductColor.valueOf(argColor));
		cartItem.setItemImagePath(argWrapProduct.getWrapProdImagePath());

		cartItem.setItemDiscountTotal(round(
				argWrapProduct.getWrapProdDiscountPercent(), 2));
		cartItem.setItemTaxTotal(round(argWrapProduct.getWrapProdTaxPercent(),
				2));
		cartItem.setItemShippingTotal(round(
				argWrapProduct.getWrapProdShippingChargePercent(), 2));
		cartItem.setItemSubToal(round(argWrapProduct.getWrapProdMarkedPrice(),
				2));
		cartItem.setItemMarkedPrice(round(
				argWrapProduct.getWrapProdMarkedPrice(), 2));
		return cartItem;
	}

	public Object roundVariables(Object object)
			throws IllegalArgumentException, IllegalAccessException {
		Field[] fields = object.getClass().getFields();
		for (Field field : fields) {
			if (field.getType() == double.class) {
				field.getDouble(field);
			}
		}
		return object;

	}

	/**
	 * @param argWrapCart
	 * @return
	 */
	public Object roundObjectVariables(Object object) {
		if (object!=null && object instanceof WrapCart) {
			WrapCart wrapCart = (WrapCart) object;
			wrapCart.setWrapCartDiscountTotal(round(
					wrapCart.getWrapCartDiscountTotal(), 2));
			wrapCart.setWrapCartPayable(round(wrapCart.getWrapCartPayable(), 2));
			wrapCart.setWrapCartShippingTotal(round(
					wrapCart.getWrapCartShippingTotal(), 2));
			wrapCart.setWrapCartSubToal(round(wrapCart.getWrapCartSubToal(), 2));
			wrapCart.setWrapCartTaxTotal(round(wrapCart.getWrapCartTaxTotal(),
					2));
			return wrapCart;
		} else if (object!=null && object instanceof WrapCartItem) {
			WrapCartItem wrapCartItem = (WrapCartItem) object;
			wrapCartItem.setItemDiscountTotal(round(
					wrapCartItem.getItemDiscountTotal(), 2));
			wrapCartItem.setItemMarkedPrice(round(
					wrapCartItem.getItemMarkedPrice(), 2));
			wrapCartItem.setItemTaxTotal(round(wrapCartItem.getItemTaxTotal(),
					2));
			wrapCartItem
			.setItemSubToal(round(wrapCartItem.getItemSubToal(), 2));
			wrapCartItem.setItemShippingTotal(round(
					wrapCartItem.getItemShippingTotal(), 2));
			return wrapCartItem;
		}
		return object;
	}

	public String createUserName() {
		int i = wrapUserDaoImpl.getUserAccountCount();
		String userName = "user" + (i + 1);
		return userName;
	}

	public WrapUser getLoggedInUserInfo(String argUserName) {
		return wrapUserDaoImpl.getWrapUserByUsername(argUserName);
	}
	
	public List<WrapCustomer> getWrapCustomers() {
		return wrapUserDaoImpl.getWrapCustomers();
	}
	
	public WrapCustomerManagement getCustomerManagement(){
		WrapCustomerManagement customerManagement = new WrapCustomerManagement();
		customerManagement.setCustomerList(getWrapCustomers());
		customerManagement.setTotalUserCount(0);
		customerManagement.setActiveUserCount(0);
		customerManagement.setInactiveUserCount(0);
		return customerManagement;
	}

	public String getLoggedInUserTitleBar(String argFirstName) {
		return "<ul class='userMenu'> <li><a href='account'><span class='hidden-xs'> My Account</span> <i class='glyphicon glyphicon-user hide visible-xs '></i></a></li> <li class='dropdown hasUserMenu'><a href='#' class='dropdown-toggle' data-toggle='dropdown' aria-expanded='false'> <i class='glyphicon glyphicon-log-in hide visible-xs '></i> Hi, "
				+ argFirstName
				+ " <b class='caret'></b></a> <ul class='dropdown-menu'> <li><a href='account.html'> <i class='fa fa-user'></i> Account</a></li> <li><a href='account.html'><i class='fa fa fa-cog'></i> Profile</a></li> <li><a href='my-address.html'><i class='fa fa-map-marker'></i> Addresses</a></li> <li><a href='order-list.html'><i class='fa  fa-calendar'></i> Orders</a></li> <li><a href='wishlist.html' title='My wishlists'> <i class='fa fa-heart'></i> My wishlists </a></li> <li class='divider'></li> <li><a href='logout'><i class='fa  fa-sign-out'></i> Log Out</a></li> </ul> </li> </ul>";
	}

	public String getAdminTitleBar(String argFirstName) {
		return "<ul class='userMenu'> " +
					"<li>" +
						"<a href='account'>" +
							"<span class='hidden-xs'> My Account</span>" +
							" <i class='glyphicon glyphicon-user hide visible-xs '></i>" +
						 "</a>" +
					"</li> " +
					"<li class='dropdown hasUserMenu'>" +
						"<a href='#' class='dropdown-toggle' data-toggle='dropdown' aria-expanded='false'>" +
							" <i class='glyphicon glyphicon-log-in hide visible-xs '></i> Hi, "+argFirstName+" <b class='caret'></b></a>" +
							" <ul class='dropdown-menu'> " +
								"<li>" +
									"<a href='account.html'><i class='fa fa fa-cog'></i> Profile</a>" +
								"</li> " +
								"<li>" +
									"<a href='order-list.html'><i class='fa  fa-calendar'></i> Orders</a>" +
								"</li> " +
								"<li>" +
									"<a href='wishlist.html' title='My wishlists'> <i class='fa fa-heart'></i> My wishlists </a>" +
								"</li> " +
								"<li class='divider'></li> " +
								"<li>" +
									"<a href='logout'><i class='fa  fa-sign-out'></i> Log Out</a>" +
								"</li>" +
							" </ul>" +
						" </li>" +
					" </ul>";
	}

	public String getGuestUserTitleBar() {
		return "<ul class='userMenu'>  <li><a href='#' data-toggle='modal' data-target='#ModalLogin'> <span class='hidden-xs'>Sign In</span> <i class='glyphicon glyphicon-log-in hide visible-xs '> </i> </a></li> <li class='hidden-xs'><a href='#' data-toggle='modal' data-target='#ModalSignup'> Create Account </a> </li> </ul>";
	}

	public WrapOrder finalizeOrder(WrapOrder argWrapOrder) {

		WrapUser wrapUser = argWrapOrder.getWrapUser();
		WrapUserAddress wrapUserAddress = argWrapOrder.getWrapUserAddress();
		WrapUserCard wrapUserCard = argWrapOrder.getWrapUserCard();
		WrapCart wrapCart = argWrapOrder.getWrapCart();

		argWrapOrder.setOrderUserId(wrapUser.getUserName());
		argWrapOrder.setOrderAddressId(wrapUserAddress.getUser_address_id());
		argWrapOrder.setOrderCardId(wrapUserCard.getUserCCId());
		argWrapOrder.setOrderId("WRAP-ORDER_" + wrapUser.getUserName()
				+ new Date().getTime());
		argWrapOrder.setOrderDate(new Date());
		argWrapOrder.setOrderTotal(wrapCart.getWrapCartPayable());
		argWrapOrder.setOrderStatus("PENDING");

		return argWrapOrder;
	}

}
