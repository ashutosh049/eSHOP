/**
 * 
 */
package com.wrap.util;

import java.util.*;

import com.wrap.modal.WrapCustomer;
import com.wrap.modal.WrapCustomerManagement;

/**
 * DESCRIPTION GOES HERE<br>
 * <br>
 * Copyright (c) 2016 kumar.ashutosh@skillnetinc.com
 *
 * @author ashu
 * @created Oct 21, 2016
 * @version $Revision$
 */
public class WrapCustomerUtil extends WrapUtil{
	
}
