/**
 * 
 */
package com.wrap.imodal;

/**
 * DESCRIPTION GOES HERE<br>
 * <br>
 * Copyright (c) 2016 kumar.ashutosh@skillnetinc.com
 *
 * @author ashu
 * @created Oct 15, 2016
 * @version $Revision$
 */
public enum WrapProductColor {
	YELLOW, GREY, GREEN,
}
