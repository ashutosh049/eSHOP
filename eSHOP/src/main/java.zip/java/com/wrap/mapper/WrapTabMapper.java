/**
 * 
 */
package com.wrap.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.wrap.modal.WrapTab;

/**
 * @author ashu
 * 
 */
public class WrapTabMapper implements RowMapper<WrapTab> {

	@Override
	public WrapTab mapRow(ResultSet arg0, int arg1) throws SQLException {
		// TODO Auto-generated method stub
		
		return null;
	}

}
