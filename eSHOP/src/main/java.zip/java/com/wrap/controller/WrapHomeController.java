/**
 * 
 */
package com.wrap.controller;

import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.wrap.daoimpl.WrapOrderDaoImpl;
import com.wrap.daoimpl.WrapUserAddressDaoImpl;
import com.wrap.daoimpl.WrapUserDaoImpl;
import com.wrap.modal.WrapCart;
import com.wrap.modal.WrapCartItem;
import com.wrap.modal.WrapNavModal;
import com.wrap.modal.WrapOrder;
import com.wrap.modal.WrapProduct;
import com.wrap.modal.WrapUser;
import com.wrap.modal.WrapUserAddress;
import com.wrap.modal.WrapUserCard;
import com.wrap.util.WrapCalculator;
import com.wrap.util.WrapUtil;

/**
 * Basic controller class for redirection to home or index.<br>
 * <br>
 * Copyright (c) 2016 kumar.ashutosh@skillnetinc.com
 * 
 * @author ashu
 * @created Oct 10, 2016
 * @version $Revision$
 */

@Component
@ComponentScan("com.wrap.controller")
@RestController
@SessionAttributes({ "wrapCart", "wrapUserSession" })
public class WrapHomeController {

	@Autowired
	WrapNavModal wrapNavModal;
	@Autowired
	WrapUtil wrapUtil;
	@Autowired
	WrapCalculator wrapCalculator;
	@Autowired
	WrapUserDaoImpl wrapUserDaoImpl;
	@Autowired
	WrapUserAddressDaoImpl wrapUserAddressDaoImpl;
	@Autowired
	private HttpSession httpSession;
	@Autowired
	WrapOrder wrapOrder;
	@Autowired
	WrapOrderDaoImpl wrapOrderDaoImpl;
	@Autowired
	WrapUserDaoImpl WrapUserDaoImpl;

	@RequestMapping({ "/", "/index" })
	public ModelAndView helloWorld(final Model model, final Locale locale,
			HttpSession argHttpSession) {
		model.addAttribute("message", "Hello World!");
		wrapNavModal = wrapUtil.getWrapNavModal();
		model.addAttribute("wrapNavModal", wrapNavModal);

		String titleBar = (String) httpSession.getAttribute("titleBar");
		if (titleBar == null || titleBar == "") {
			titleBar = wrapUtil.getGuestUserTitleBar();
		}
		model.addAttribute("titleBar", titleBar);
		WrapCart wrapCart = (WrapCart) argHttpSession.getAttribute("wrapCart");
		if (wrapCart == null) {
			wrapCart = new WrapCart();
			argHttpSession.setAttribute("wrapCart", wrapCart);
		}
		model.addAttribute("wrapCart", wrapCart);

		return new ModelAndView("index");
	}

	@RequestMapping({ "/category" })
	public ModelAndView showCategory(final Model model, final Locale locale,
			HttpSession argHttpSession, @RequestParam("tabId") String tabId,
			@RequestParam("colId") String colId,
			@RequestParam("catId") String catId) {
		model.addAttribute("wrapNavModal", wrapNavModal);
		List<WrapProduct> wrapProductList = wrapUtil.getWrapProducts(tabId,
				colId, catId);
		model.addAttribute("wrapProductList", wrapProductList);

		String titleBar = (String) httpSession.getAttribute("titleBar");
		if (titleBar == null || titleBar == "") {
			titleBar = wrapUtil.getGuestUserTitleBar();
		}
		WrapCart wrapCart = (WrapCart) argHttpSession.getAttribute("wrapCart");
		if (wrapCart == null) {
			wrapCart = new WrapCart();
			argHttpSession.setAttribute("wrapCart", wrapCart);
		}
		model.addAttribute("wrapCart", wrapCart);
		model.addAttribute("titleBar", titleBar);
		return new ModelAndView("category");
	}

	@RequestMapping({ "/productDetails" })
	public ModelAndView productDetails(final Model model, final Locale locale,
			HttpSession argHttpSession, @RequestParam("tabId") String tabId,
			@RequestParam("colId") String colId,
			@RequestParam("catId") String catId,
			@RequestParam("prodId") String prodId) {
		model.addAttribute("wrapNavModal", wrapNavModal);
		WrapProduct wrapProduct = wrapUtil.getWrapProducts(tabId, colId, catId,
				prodId);
		model.addAttribute("wrapProduct", wrapProduct);
		List<WrapProduct> mayAlsoLikeWrapProductList = wrapUtil
				.getWrapProducts(tabId, colId, catId);
		model.addAttribute("mayAlsoLikeWrapProductList",
				mayAlsoLikeWrapProductList);

		int randReqItemCount = new Random().nextInt(2) + 1;

		List<WrapProduct> freqBaughtTogetherWrapProductList = wrapUtil
				.getAlsoBaughtTogetherWrapProductsByTabByColIds(tabId, colId,
						catId, randReqItemCount);
		model.addAttribute("freqBaughtTogetherWrapProductList",
				freqBaughtTogetherWrapProductList);
		String freqBaughtTogetherWrapProductListDesc = "By these product together and get extra "
				+ (randReqItemCount * 5) + " % discount";
		model.addAttribute("freqBaughtTogetherWrapProductListDesc",
				freqBaughtTogetherWrapProductListDesc);

		double freqTotalProducts = 0;
		double freqTotalShipping = 0;
		double freqTotalDiscount = 0;
		double freqTotalotalTax = 0;
		double freqTotal = 0;

		for (WrapProduct freqProduct : freqBaughtTogetherWrapProductList) {
			freqTotalProducts += freqProduct.getWrapProdMarkedPrice();
			freqTotalDiscount += freqProduct.getWrapProdDiscountPercent();
		}

		freqTotalProducts += wrapProduct.getWrapProdMarkedPrice();
		freqTotalDiscount += wrapProduct.getWrapProdDiscountPercent();

		freqTotalProducts = wrapUtil.round(freqTotalProducts, 2);
		freqTotalDiscount += 10;
		freqTotalDiscount = wrapUtil.round(freqTotalDiscount, 2);
		freqTotal = freqTotalProducts
				- (freqTotalProducts * (freqTotalDiscount / 100));
		freqTotal = wrapUtil.round(freqTotal, 2);

		model.addAttribute("freqTotalProducts", freqTotalProducts);
		model.addAttribute("freqTotalDiscount", freqTotalDiscount);
		model.addAttribute("freqTotalShipping", freqTotalShipping);
		model.addAttribute("freqTotalotalTax", freqTotalotalTax);
		model.addAttribute("freqTotal", freqTotal);

		model.addAttribute("wrapCartItem", new WrapCartItem());

		String titleBar = (String) httpSession.getAttribute("titleBar");
		if (titleBar == null || titleBar == "") {
			titleBar = wrapUtil.getGuestUserTitleBar();
		}
		model.addAttribute("titleBar", titleBar);
		WrapCart wrapCart = (WrapCart) argHttpSession.getAttribute("wrapCart");
		if (wrapCart == null) {
			wrapCart = new WrapCart();
			argHttpSession.setAttribute("wrapCart", wrapCart);
		}
		model.addAttribute("wrapCart", wrapCart);
		return new ModelAndView("product-details");
	}

	@RequestMapping(value = { "/addToCart", "/cart" }, method = RequestMethod.GET)
	public ModelAndView addNewItemToCart(final Model model,
			final Locale locale, HttpServletRequest request,
			HttpSession argHttpSession) throws IllegalArgumentException,
			IllegalAccessException {
		/*
		 * WrapCart wrapCart = (WrapCart)
		 * argHttpSession.getAttribute("wrapCart"); if(wrapCart==null){ wrapCart
		 * = new WrapCart(); argHttpSession.setAttribute("wrapCart", wrapCart);
		 * } model.addAttribute("wrapCart", wrapCart);
		 * 
		 * String titleBar = (String)httpSession.getAttribute("titleBar");
		 * if(titleBar==null || titleBar==""){ titleBar =
		 * wrapUtil.getGuestUserTitleBar(); } model.addAttribute("titleBar",
		 * titleBar); model.addAttribute("wrapNavModal", wrapNavModal);
		 * 
		 * return new ModelAndView("cart");
		 */
		String itemTabId = (String) request.getParameter("itemTabId");
		String itemColId = (String) request.getParameter("itemColId");
		String itemCatId = (String) request.getParameter("itemCatId");
		String itemId = (String) request.getParameter("itemId");
		int itemCount = Integer.parseInt(request.getParameter("itemCount"));
		String itemSize = (String) request.getParameter("itemSize");
		model.addAttribute("wrapNavModal", wrapNavModal);

		WrapCart wrapCart = (WrapCart) argHttpSession.getAttribute("wrapCart");
		WrapCartItem cartItem = null;
		if (itemTabId != null && itemColId != null && itemCatId != null
				&& itemId != null) {
			WrapProduct wrapProduct = wrapUtil.getWrapProducts(itemTabId,
					itemColId, itemCatId, itemId);
			cartItem = wrapUtil.castWrapProuctToWrapCartItem(wrapProduct,
					itemCount, itemSize, null);
		}
		if (wrapCart == null) {
			wrapCart = new WrapCart();
		}
		wrapCart = wrapCalculator.updateWrapCartItem(wrapCart, cartItem,
				itemCount);
		wrapCart = (WrapCart) wrapUtil.roundObjectVariables(wrapCart);
		model.addAttribute("wrapCart", wrapCart);
		argHttpSession.setAttribute("wrapCart", wrapCart);

		String titleBar = (String) httpSession.getAttribute("titleBar");
		if (titleBar == null || titleBar == "") {
			titleBar = wrapUtil.getGuestUserTitleBar();
		}
		model.addAttribute("titleBar", titleBar);
		model.addAttribute("wrapNavModal", wrapNavModal);
		return new ModelAndView("cart");
	}

	@RequestMapping(value = "/addToCart", method = RequestMethod.POST)
	public ModelAndView addNewItemToCart1(final Model model,
			final Locale locale, HttpServletRequest request,
			HttpSession argHttpSession) throws IllegalArgumentException,
			IllegalAccessException {

		String itemTabId = (String) request.getParameter("itemTabId");
		String itemColId = (String) request.getParameter("itemColId");
		String itemCatId = (String) request.getParameter("itemCatId");
		String itemId = (String) request.getParameter("itemId");
		int itemCount = Integer.parseInt(request.getParameter("itemCount"));
		String itemSize = (String) request.getParameter("itemSize");
		model.addAttribute("wrapNavModal", wrapNavModal);

		WrapCart wrapCart = (WrapCart) argHttpSession.getAttribute("wrapCart");
		WrapCartItem cartItem = null;
		if (itemTabId != null && itemColId != null && itemCatId != null
				&& itemId != null) {
			WrapProduct wrapProduct = wrapUtil.getWrapProducts(itemTabId,
					itemColId, itemCatId, itemId);
			cartItem = wrapUtil.castWrapProuctToWrapCartItem(wrapProduct,
					itemCount, itemSize, null);
		}
		if (wrapCart == null) {
			wrapCart = new WrapCart();
		}
		wrapCart = wrapCalculator.updateWrapCartItem(wrapCart, cartItem,
				itemCount);
		wrapCart = (WrapCart) wrapUtil.roundObjectVariables(wrapCart);
		model.addAttribute("wrapCart", wrapCart);
		argHttpSession.setAttribute("wrapCart", wrapCart);

		String titleBar = (String) httpSession.getAttribute("titleBar");
		if (titleBar == null || titleBar == "") {
			titleBar = wrapUtil.getGuestUserTitleBar();
		}
		model.addAttribute("titleBar", titleBar);
		model.addAttribute("wrapNavModal", wrapNavModal);
		return new ModelAndView("cart");
	}

	@RequestMapping(value = "/removeFromCart", method = RequestMethod.GET)
	public ModelAndView removeFromCart(final Model model, final Locale locale,
			HttpServletRequest request, HttpSession argHttpSession)
			throws IllegalArgumentException, IllegalAccessException {

		String itemTabId = (String) request.getParameter("itemTabId");
		String itemColId = (String) request.getParameter("itemColId");
		String itemCatId = (String) request.getParameter("itemCatId");
		String itemId = (String) request.getParameter("itemId");
		int itemCount = Integer.parseInt(request.getParameter("itemCount"));
		String itemSize = (String) request.getParameter("itemSize");
		model.addAttribute("wrapNavModal", wrapNavModal);

		WrapCart wrapCart = (WrapCart) argHttpSession.getAttribute("wrapCart");
		WrapCartItem cartItem = null;
		if (itemTabId != null && itemColId != null && itemCatId != null
				&& itemId != null) {
			WrapProduct wrapProduct = wrapUtil.getWrapProducts(itemTabId,
					itemColId, itemCatId, itemId);
			cartItem = wrapUtil.castWrapProuctToWrapCartItem(wrapProduct,
					itemCount, itemSize, null);
		}

		wrapCart = wrapCalculator.removeWrapCartItem(wrapCart, cartItem,
				itemCount);
		wrapCart = (WrapCart) wrapUtil.roundObjectVariables(wrapCart);
		model.addAttribute("wrapCart", wrapCart);
		argHttpSession.setAttribute("wrapCart", wrapCart);

		String titleBar = (String) httpSession.getAttribute("titleBar");
		if (titleBar == null || titleBar == "") {
			titleBar = wrapUtil.getGuestUserTitleBar();
		}
		model.addAttribute("titleBar", titleBar);
		model.addAttribute("wrapNavModal", wrapNavModal);
		return new ModelAndView("cart");
	}

	// checkout

	@RequestMapping({ "/authenticate" })
	public ModelAndView authenticate(final Model model, final Locale locale,
			HttpSession argHttpSession) {
		model.addAttribute("wrapUser", new WrapUser());

		String titleBar = (String) httpSession.getAttribute("titleBar");
		if (titleBar == null || titleBar == "") {
			titleBar = wrapUtil.getGuestUserTitleBar();
		}
		model.addAttribute("titleBar", titleBar);
		model.addAttribute("wrapNavModal", wrapNavModal);
		return new ModelAndView("authenticate");
	}

	@RequestMapping(value = "/createUserAccount", method = RequestMethod.POST, headers = "Accept=application/json", produces = "application/json")
	public @ResponseBody
	WrapUser createUserAccount(@RequestBody WrapUser argWrapUser) {
		System.out.println("argWrapUser" + argWrapUser.getFirstName());
		String userName = wrapUtil.createUserName();
		argWrapUser.setUserName(userName);
		if (argWrapUser.getFirstName() != null
				&& argWrapUser.getLastName() != null
				&& argWrapUser.getEmail() != null
				&& argWrapUser.getPassword() != null && argWrapUser.getFirstName() != ""
				&& argWrapUser.getLastName() != ""
				&& argWrapUser.getEmail() != ""
				&& argWrapUser.getPassword() != "") {

			if (wrapUserDaoImpl.createWrapUser(argWrapUser)) {
				if (wrapUserDaoImpl.createWrapUserCredentials(argWrapUser)) {
					if (wrapUserDaoImpl.createWrapUserRoles(argWrapUser)) {
						return argWrapUser;
					}
				}
			}
		}
		return null;
	}

	@RequestMapping(value = "/add-address", method = RequestMethod.GET)
	public ModelAndView addAddress(final Model model, final Locale locale,
			HttpSession argHttpSession) {
		wrapNavModal = wrapUtil.getWrapNavModal();
		model.addAttribute("wrapNavModal", wrapNavModal);
		String titleBar = (String) httpSession.getAttribute("titleBar");
		if (titleBar == null || titleBar == "") {
			titleBar = wrapUtil.getGuestUserTitleBar();
		}
		model.addAttribute("titleBar", titleBar);
		model.addAttribute("wrapNavModal", wrapNavModal);

		WrapUser wrapUser = (WrapUser) httpSession
				.getAttribute("wrapUserSession");
		if (wrapUser == null) {
			String username = (String) httpSession.getAttribute("username");
			wrapUser = wrapUtil.getLoggedInUserInfo(username);
		}

		WrapUserAddress userAddress = wrapUserAddressDaoImpl
				.getWrapUserAddress(wrapUser.getUserName());

		if (userAddress == null) {
			userAddress = new WrapUserAddress();
		}
		model.addAttribute("wrapUserAddress", userAddress);

		WrapCart wrapCart = (WrapCart) argHttpSession.getAttribute("wrapCart");
		if (wrapCart == null) {
			wrapCart = new WrapCart();
			argHttpSession.setAttribute("wrapCart", wrapCart);
		}
		model.addAttribute("wrapCart", wrapCart);

		return new ModelAndView("add-address");
	}

	@RequestMapping(value = "/addNewAddress", method = RequestMethod.POST)
	public ModelAndView addNewAddress(final Model model, final Locale locale,
			HttpSession argHttpSession,
			@ModelAttribute WrapUserAddress wrapUserAddress) {
		wrapNavModal = wrapUtil.getWrapNavModal();
		model.addAttribute("wrapNavModal", wrapNavModal);
		String titleBar = (String) httpSession.getAttribute("titleBar");
		if (titleBar == null || titleBar == "") {
			titleBar = wrapUtil.getGuestUserTitleBar();
		}
		model.addAttribute("titleBar", titleBar);
		model.addAttribute("wrapNavModal", wrapNavModal);

		WrapUser wrapUser = (WrapUser) httpSession
				.getAttribute("wrapUserSession");
		if (wrapUser == null) {
			String username = (String) httpSession.getAttribute("username");
			wrapUser = wrapUtil.getLoggedInUserInfo(username);
		}

		int i = wrapUserAddressDaoImpl.getUserAccountCount(wrapUser
				.getUserName()) + 1;

		wrapUserAddress.setUserName(wrapUser.getUserName());
		wrapUserAddress.setUser_address_id(wrapUser.getUserName() + "_adrs_"
				+ i);

		WrapUserAddress userAddress = wrapUserAddressDaoImpl
				.getWrapUserAddress(wrapUser.getUserName());

		if (userAddress == null) {
			if (wrapUserAddressDaoImpl.createWrapUserAddress(wrapUserAddress)) {
				return new ModelAndView("account");
			}
		} else {
			if (wrapUserAddressDaoImpl.updateWrapUserAddress(wrapUserAddress)) {
				return new ModelAndView("account");
			}
		}

		WrapCart wrapCart = (WrapCart) argHttpSession.getAttribute("wrapCart");
		if (wrapCart == null) {
			wrapCart = new WrapCart();
			argHttpSession.setAttribute("wrapCart", wrapCart);
		}
		model.addAttribute("wrapCart", wrapCart);

		return new ModelAndView("add-address");
	}

	@RequestMapping(value = "/my-address", method = RequestMethod.GET)
	public ModelAndView MyAddress(final Model model, final Locale locale,
			@ModelAttribute WrapUserAddress wrapUserAddress,
			HttpSession argHttpSession) {
		wrapNavModal = wrapUtil.getWrapNavModal();
		model.addAttribute("wrapNavModal", wrapNavModal);
		String titleBar = (String) httpSession.getAttribute("titleBar");
		if (titleBar == null || titleBar == "") {
			titleBar = wrapUtil.getGuestUserTitleBar();
		}
		model.addAttribute("titleBar", titleBar);
		model.addAttribute("wrapNavModal", wrapNavModal);

		WrapUser wrapUser = (WrapUser) argHttpSession
				.getAttribute("wrapUserSession");
		if (wrapUser == null) {
			String username = (String) httpSession.getAttribute("username");
			wrapUser = wrapUtil.getLoggedInUserInfo(username);
		}

		WrapCart wrapCart = (WrapCart) argHttpSession.getAttribute("wrapCart");
		if (wrapCart == null) {
			wrapCart = new WrapCart();
			argHttpSession.setAttribute("wrapCart", wrapCart);
		}
		model.addAttribute("wrapCart", wrapCart);

		WrapUserAddress address = wrapUserAddressDaoImpl
				.getWrapUserAddress(wrapUser.getUserName());
		model.addAttribute("address", address);
		return new ModelAndView("my-address");

	}

	@RequestMapping({ "/account" })
	public ModelAndView myAccount(final Model model, final Locale locale,
			HttpSession argHttpSession) {
		wrapNavModal = wrapUtil.getWrapNavModal();
		model.addAttribute("wrapNavModal", wrapNavModal);
		String titleBar = (String) httpSession.getAttribute("titleBar");
		if (titleBar == null || titleBar == "") {
			titleBar = wrapUtil.getGuestUserTitleBar();
		}
		model.addAttribute("titleBar", titleBar);
		WrapCart wrapCart = (WrapCart) argHttpSession.getAttribute("wrapCart");
		if (wrapCart == null) {
			wrapCart = new WrapCart();
			argHttpSession.setAttribute("wrapCart", wrapCart);
		}
		model.addAttribute("wrapCart", wrapCart);
		return new ModelAndView("account");
	}

	// checkout----------------

	@RequestMapping({ "/checkout-1" })
	public ModelAndView checkout1(final Model model, final Locale locale,
			HttpSession argHttpSession) {
		wrapNavModal = wrapUtil.getWrapNavModal();
		model.addAttribute("wrapNavModal", wrapNavModal);
		String titleBar = (String) httpSession.getAttribute("titleBar");
		if (titleBar == null || titleBar == "") {
			titleBar = wrapUtil.getGuestUserTitleBar();
		}
		model.addAttribute("titleBar", titleBar);

		WrapUser wrapUser = (WrapUser) httpSession
				.getAttribute("wrapUserSession");

		if (wrapUser == null) {
			String username = (String) httpSession.getAttribute("username");
			wrapUser = wrapUtil.getLoggedInUserInfo(username);
		}

		WrapCart wrapCart = (WrapCart) argHttpSession.getAttribute("wrapCart");
		if (wrapCart == null) {
			wrapCart = new WrapCart();
			argHttpSession.setAttribute("wrapCart", wrapCart);
		}
		model.addAttribute("wrapCart", wrapCart);

		WrapUserAddress wrapUserAddress = wrapUserAddressDaoImpl
				.getWrapUserAddress(wrapUser.getUserName());
		model.addAttribute("wrapUserAddress", wrapUserAddress);
		return new ModelAndView("checkout-1");
	}

	@RequestMapping({ "/checkout-4" })
	public ModelAndView checkout4(final Model model, final Locale locale,
			@ModelAttribute WrapUserAddress wrapUserAddress,
			HttpSession argHttpSession) {
		wrapNavModal = wrapUtil.getWrapNavModal();
		model.addAttribute("wrapNavModal", wrapNavModal);
		String titleBar = (String) httpSession.getAttribute("titleBar");
		if (titleBar == null || titleBar == "") {
			titleBar = wrapUtil.getGuestUserTitleBar();
		}
		model.addAttribute("titleBar", titleBar);

		WrapUser wrapUser = (WrapUser) httpSession
				.getAttribute("wrapUserSession");
		if (wrapUser == null) {
			String username = (String) httpSession.getAttribute("username");
			wrapUser = wrapUtil.getLoggedInUserInfo(username);
		}

		int i = wrapUserAddressDaoImpl.getUserAccountCount(wrapUser
				.getUserName()) + 1;

		wrapUserAddress.setUserName(wrapUser.getUserName());
		wrapUserAddress.setUser_address_id(wrapUser.getUserName() + "_adrs_"
				+ i);

		WrapUserAddress userAddress = wrapUserAddressDaoImpl
				.getWrapUserAddress(wrapUser.getUserName());

		WrapCart wrapCart = (WrapCart) argHttpSession.getAttribute("wrapCart");
		if (wrapCart == null) {
			wrapCart = new WrapCart();
			argHttpSession.setAttribute("wrapCart", wrapCart);
		}
		model.addAttribute("wrapCart", wrapCart);

		if (userAddress == null) {
			if (wrapUserAddressDaoImpl.createWrapUserAddress(wrapUserAddress)) {
				model.addAttribute("wrapUserCard", new WrapUserCard());
				wrapOrder.setWrapUser(wrapUser);
				wrapOrder.setWrapUserAddress(userAddress);
				return new ModelAndView("checkout-4");
			}
		} else {
			if (wrapUserAddressDaoImpl.updateWrapUserAddress(wrapUserAddress)) {
				wrapOrder.setWrapUser(wrapUser);
				wrapOrder.setWrapUserAddress(userAddress);
				model.addAttribute("wrapUserCard", new WrapUserCard());
				return new ModelAndView("checkout-4");
			}
		}

		return new ModelAndView("checkout-1");
	}

	@RequestMapping({ "/checkout-5" })
	public ModelAndView checkout5(final Model model, final Locale locale,
			@ModelAttribute WrapUserCard wrapUserCard,
			HttpSession argHttpSession) {
		wrapNavModal = wrapUtil.getWrapNavModal();
		model.addAttribute("wrapNavModal", wrapNavModal);
		String titleBar = (String) httpSession.getAttribute("titleBar");
		if (titleBar == null || titleBar == "") {
			titleBar = wrapUtil.getGuestUserTitleBar();
		}
		model.addAttribute("titleBar", titleBar);

		WrapCart wrapCart = (WrapCart) argHttpSession.getAttribute("wrapCart");
		if (wrapCart == null) {
			wrapCart = new WrapCart();
			argHttpSession.setAttribute("wrapCart", wrapCart);
		}
		model.addAttribute("wrapCart", wrapCart);
		wrapOrder.setWrapCart(wrapCart);

		WrapUser wrapUser = (WrapUser) httpSession
				.getAttribute("wrapUserSession");
		if (wrapUser == null) {
			String username = (String) httpSession.getAttribute("username");
			wrapUser = wrapUtil.getLoggedInUserInfo(username);
		}

		wrapUserCard.setUserName(wrapUser.getUserName());
		wrapUserCard.setUserCCId("CC_" + wrapUser.getUserName() + "_"
				+ new Date().getTime());
		wrapUserCard.setCcType("CREDIT CARD");
		wrapOrder.setWrapUserCard(wrapUserCard);
		return new ModelAndView("checkout-5");
	}

	@RequestMapping({ "/thanks-for-order" })
	public ModelAndView thanksForOrder(final Model model, final Locale locale,
			HttpSession argHttpSession) {
		wrapNavModal = wrapUtil.getWrapNavModal();
		model.addAttribute("wrapNavModal", wrapNavModal);
		String titleBar = (String) httpSession.getAttribute("titleBar");
		if (titleBar == null || titleBar == "") {
			titleBar = wrapUtil.getGuestUserTitleBar();
		}
		model.addAttribute("titleBar", titleBar);

		WrapUser wrapUser = (WrapUser) httpSession
				.getAttribute("wrapUserSession");
		if (wrapUser == null) {
			String username = (String) httpSession.getAttribute("username");
			wrapUser = wrapUtil.getLoggedInUserInfo(username);
		}

		WrapCart wrapCart = (WrapCart) argHttpSession.getAttribute("wrapCart");
		if (wrapCart == null) {
			wrapCart = new WrapCart();
			argHttpSession.setAttribute("wrapCart", wrapCart);
		}
		model.addAttribute("wrapCart", wrapCart);
		wrapOrder.setWrapCart(wrapCart);
		wrapUtil.finalizeOrder(wrapOrder);
		if (wrapOrderDaoImpl.createWrapOrder(wrapOrder)) {
			model.addAttribute("wrapOrder", wrapOrder);
			return new ModelAndView("thanks-for-order");
		}
		return new ModelAndView("checkout-5");

	}

	@RequestMapping({ "/order-list" })
	public ModelAndView userOrderList(final Model model, final Locale locale,
			HttpSession argHttpSession) {
		wrapNavModal = wrapUtil.getWrapNavModal();
		model.addAttribute("wrapNavModal", wrapNavModal);
		String titleBar = (String) httpSession.getAttribute("titleBar");
		if (titleBar == null || titleBar == "") {
			titleBar = wrapUtil.getGuestUserTitleBar();
		}
		model.addAttribute("titleBar", titleBar);
		model.addAttribute("wrapNavModal", wrapNavModal);
		WrapCart wrapCart = (WrapCart) argHttpSession.getAttribute("wrapCart");
		if (wrapCart == null) {
			wrapCart = new WrapCart();
			argHttpSession.setAttribute("wrapCart", wrapCart);
		}
		model.addAttribute("wrapCart", wrapCart);

		WrapUser wrapUser = (WrapUser) httpSession
				.getAttribute("wrapUserSession");
		if (wrapUser == null) {
			String username = (String) httpSession.getAttribute("username");
			wrapUser = wrapUtil.getLoggedInUserInfo(username);
		}

		List<WrapOrder> wrapOrderList = wrapOrderDaoImpl.getWrapOrder(wrapUser
				.getUserName());
		model.addAttribute("wrapOrderList", wrapOrderList);

		return new ModelAndView("order-list");

	}

	@RequestMapping({ "/user-information" })
	public ModelAndView userPersonalInformation(final Model model,
			final Locale locale, HttpSession argHttpSession) {
		wrapNavModal = wrapUtil.getWrapNavModal();
		model.addAttribute("wrapNavModal", wrapNavModal);
		String titleBar = (String) httpSession.getAttribute("titleBar");
		if (titleBar == null || titleBar == "") {
			titleBar = wrapUtil.getGuestUserTitleBar();
		}
		model.addAttribute("titleBar", titleBar);
		model.addAttribute("wrapNavModal", wrapNavModal);
		WrapCart wrapCart = (WrapCart) argHttpSession.getAttribute("wrapCart");
		if (wrapCart == null) {
			wrapCart = new WrapCart();
			argHttpSession.setAttribute("wrapCart", wrapCart);
		}
		model.addAttribute("wrapCart", wrapCart);

		WrapUser wrapUser = (WrapUser) httpSession
				.getAttribute("wrapUserSession");
		if (wrapUser == null) {
			String username = (String) httpSession.getAttribute("username");
			wrapUser = wrapUtil.getLoggedInUserInfo(username);
		}
		model.addAttribute("wrapUser", wrapUser);

		return new ModelAndView("user-information");

	}

	@RequestMapping({ "/updateUserPersonalInfo" })
	public ModelAndView updateUserPersonalInfo(final Model model,
			final Locale locale, HttpSession argHttpSession,
			@ModelAttribute WrapUser argWrapUser) {
		wrapNavModal = wrapUtil.getWrapNavModal();
		model.addAttribute("wrapNavModal", wrapNavModal);
		String titleBar = (String) httpSession.getAttribute("titleBar");
		if (titleBar == null || titleBar == "") {
			titleBar = wrapUtil.getGuestUserTitleBar();
		}
		model.addAttribute("titleBar", titleBar);
		model.addAttribute("wrapNavModal", wrapNavModal);
		WrapCart wrapCart = (WrapCart) argHttpSession.getAttribute("wrapCart");
		if (wrapCart == null) {
			wrapCart = new WrapCart();
			argHttpSession.setAttribute("wrapCart", wrapCart);
		}
		model.addAttribute("wrapCart", wrapCart);

		WrapUser wrapUser = (WrapUser) httpSession
				.getAttribute("wrapUserSession");
		if (wrapUser == null) {
			String username = (String) httpSession.getAttribute("username");
			wrapUser = wrapUtil.getLoggedInUserInfo(username);
		}

		if (argWrapUser.getFirstName() != null
				&& argWrapUser.getLastName() != null
				&& argWrapUser.getEmail() != null) {
			argWrapUser.setUserName(wrapUser.getUserName());
			if (WrapUserDaoImpl.updateWrapUserInfo(argWrapUser)) {
				wrapUser = argWrapUser;
				httpSession.setAttribute("wrapUserSession", wrapUser);
			}
		}
		model.addAttribute("wrapUser", wrapUser);

		return new ModelAndView("user-information");

	}

}
