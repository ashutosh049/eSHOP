/**
 * 
 */
package com.wrap.controller;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import java.util.Locale;

/**
 * All 'unauthorized' access pages are managed by this controller class.<br>
 * <br>
 * Copyright (c) 2016 kumar.ashutosh@skillnetinc.com
 * 
 * @author ashu
 * @created Oct 10, 2016
 * @version $Revision$
 */
@Component
@ComponentScan("com.wrap.controller")
@RestController
public class WrapContentController {

	@RequestMapping("/account-1")
	public ModelAndView authSourcePage(final Model model, final Locale locale) {
		model.addAttribute("message", "Hello World!");
		return new ModelAndView("account-1");
	}

}
