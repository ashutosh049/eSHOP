package com.wrap.controller;

import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.wrap.daoimpl.WrapColumnDaoImpl;
import com.wrap.daoimpl.WrapOrderDaoImpl;
import com.wrap.daoimpl.WrapProductDaoImpl;
import com.wrap.daoimpl.WrapTabDaoImpl;
import com.wrap.daoimpl.WrapUserAddressDaoImpl;
import com.wrap.daoimpl.WrapUserDaoImpl;
import com.wrap.modal.WrapColumn;
import com.wrap.modal.WrapCustomerManagement;
import com.wrap.modal.WrapNavModal;
import com.wrap.modal.WrapOrder;
import com.wrap.modal.WrapProduct;
import com.wrap.modal.WrapTab;
import com.wrap.modal.WrapUser;
import com.wrap.util.WrapCalculator;
import com.wrap.util.WrapUtil;

/**
 * Basic controller class for redirection to home or index.<br>
 * <br>
 * Copyright (c) 2016 kumar.ashutosh@skillnetinc.com
 * 
 * @author ashu
 * @created Oct 10, 2016
 * @version $Revision$
 */

@Component
@ComponentScan("com.wrap.controller")
@RestController
@SessionAttributes({ "wrapCart", "wrapUserSession" })
public class WrapAdminController {

	@Autowired
	WrapNavModal wrapNavModal;
	@Autowired
	WrapUtil wrapUtil;
	@Autowired
	WrapCalculator wrapCalculator;
	@Autowired
	WrapUserDaoImpl wrapUserDaoImpl;
	@Autowired
	WrapUserAddressDaoImpl wrapUserAddressDaoImpl;
	@Autowired
	private HttpSession httpSession;
	@Autowired
	WrapOrder wrapOrder;
	@Autowired
	WrapOrderDaoImpl wrapOrderDaoImpl;
	@Autowired
	WrapCustomerManagement wrapCustomerManagement;
	@Autowired
	WrapTabDaoImpl wrapTabDaoImpl;
	@Autowired
	WrapColumnDaoImpl wrapColumnDaoImpl;
	@Autowired
	WrapProductDaoImpl wrapProductDaoImpl;
	

	@RequestMapping({ "/admin-panel"})
	public ModelAndView helloWorld(final Model model, final Locale locale,HttpSession argHttpSession) {
		

		WrapUser wrapUser = (WrapUser) httpSession
				.getAttribute("wrapUserSession");
		if (wrapUser == null) {
			String username = (String) httpSession.getAttribute("username");
			wrapUser = wrapUtil.getLoggedInUserInfo(username);
		}
		
		model.addAttribute("wrapUser", wrapUser);

		return new ModelAndView("admin-panel");
	}
	
	@RequestMapping({ "/customer-management"})
	public ModelAndView customerManagement(final Model model, final Locale locale,HttpSession argHttpSession) {
		

		WrapUser wrapUser = (WrapUser) httpSession
				.getAttribute("wrapUserSession");
		if (wrapUser == null) {
			String username = (String) httpSession.getAttribute("username");
			wrapUser = wrapUtil.getLoggedInUserInfo(username);
		}
		
		model.addAttribute("wrapUser", wrapUser);
		
		wrapCustomerManagement= wrapUtil.getCustomerManagement();
		model.addAttribute("wrapCustomerManagement", wrapCustomerManagement);

		return new ModelAndView("customer-management");
	}
	
	@RequestMapping(value = "/removeCustomer", method = RequestMethod.POST, headers = "Accept=application/json")
	public @ResponseBody
	Object removeCustomer(@RequestParam("custName") String custName) {
		if (wrapUserDaoImpl.removeWrapUser(custName)) {
			return "removed";
		}
		return null;
	}
	
	@RequestMapping(value = "/deactivateCustomer", method = RequestMethod.POST, headers = "Accept=application/json",produces = "application/json")
	public 	String deactivateCustomer(@RequestParam("custName") String custName) {
		if (wrapUserDaoImpl.updateUserStatus(false, custName)) {
			return "de-activated";
		}
		return null;
	}
	@RequestMapping(value = "/activateCustomer", method = RequestMethod.POST, headers = "Accept=application/json" ,produces = "application/json")
	public 	Object activateCustomer(@RequestParam("custName") String custName) {
		if (wrapUserDaoImpl.updateUserStatus(true, custName)) {
			return "activated";
		}
		return null;
	}
	
	@RequestMapping({ "/manageProductCategories"})
	public ModelAndView manageProductCategories(final Model model, final Locale locale,HttpSession argHttpSession) {
		
		WrapUser wrapUser = (WrapUser) httpSession.getAttribute("wrapUserSession");
		if (wrapUser == null) {
			String username = (String) httpSession.getAttribute("username");
			wrapUser = wrapUtil.getLoggedInUserInfo(username);
		}
		model.addAttribute("wrapUser", wrapUser);
		
		
		List<WrapTab> wrapTabList =wrapTabDaoImpl.getWrapTabs();
		model.addAttribute("wrapTabList", wrapTabList);

		return new ModelAndView("prod-cat-management");
	}
	
	@RequestMapping(value="/updateProductCategories", method = RequestMethod.POST)
	public ResponseEntity<?> updateProductCategories(HttpSession argHttpSession,@RequestBody List<WrapTab> argWrapTab) {
		
		WrapUser wrapUser = (WrapUser) httpSession.getAttribute("wrapUserSession");
		if (wrapUser == null) {
			String username = (String) httpSession.getAttribute("username");
			wrapUser = wrapUtil.getLoggedInUserInfo(username);
		}
		boolean successTabUpdate =false;
		for (WrapTab tab : argWrapTab) {
			if(tab.getWrapTabId()!=null && tab.getWrapTabName()!=null && String.valueOf(tab.getWrapTabSortOrder())!= null &&
			   tab.getWrapTabId()!="" && tab.getWrapTabName()!="" && String.valueOf(tab.getWrapTabSortOrder())!=""){
				if(wrapTabDaoImpl.updateWrapTab(tab)){
					successTabUpdate =true;
				}else{
					successTabUpdate =false;
				}
			}
		}
		if(successTabUpdate){
			return new ResponseEntity<String>("SUCCESS",HttpStatus.OK);
		}
		return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
	}
	@RequestMapping(value="/createProductCategories", method = RequestMethod.POST)
	public @ResponseBody ResponseEntity<?> createProductCategories(final Model model, final Locale locale,HttpSession argHttpSession,
			@RequestBody List<WrapTab> argWrapTab) {
		
		WrapUser wrapUser = (WrapUser) httpSession.getAttribute("wrapUserSession");
		if (wrapUser == null) {
			String username = (String) httpSession.getAttribute("username");
			wrapUser = wrapUtil.getLoggedInUserInfo(username);
		}
		model.addAttribute("wrapUser", wrapUser);
		boolean successTabCreate =false;
		model.addAttribute("status", "ERROR");
		for (WrapTab tab : argWrapTab) {
			if(tab.getWrapTabId()!=null && tab.getWrapTabName()!=null && String.valueOf(tab.getWrapTabSortOrder())!= null &&
			   tab.getWrapTabId()!="" && tab.getWrapTabName()!="" && String.valueOf(tab.getWrapTabSortOrder())!=""){
				
				tab.setWrapTabId(tab.getWrapTabId()+wrapTabDaoImpl.getWrapTabCount());
				
				if(wrapTabDaoImpl.createWrapTab(tab)){
					successTabCreate =true;
				}else{
					successTabCreate =false;
				}
			}
		}
		if(successTabCreate){
			model.addAttribute("status", "SUCCESS");
			return new ResponseEntity<String>("SUCCESS",HttpStatus.OK);
		}
		return new ResponseEntity<String>(HttpStatus.BAD_REQUEST);
	}
	
	
	@RequestMapping({ "/manageProductSection"})
	public ModelAndView manageProductSection(final Model model, final Locale locale,HttpSession argHttpSession) {
		
		WrapUser wrapUser = (WrapUser) httpSession.getAttribute("wrapUserSession");
		if (wrapUser == null) {
			String username = (String) httpSession.getAttribute("username");
			wrapUser = wrapUtil.getLoggedInUserInfo(username);
		}
		model.addAttribute("wrapUser", wrapUser);
		
		List<WrapColumn> wrapColumnList = wrapColumnDaoImpl.getWrapColumnListByTabId(null);
		model.addAttribute("wrapColumnList", wrapColumnList);

		return new ModelAndView("prod-sec-management");
	}
	
	
	@RequestMapping({ "/manageProductItems"})
	public ModelAndView manageProductItems(final Model model, final Locale locale,HttpSession argHttpSession) {
		
		WrapUser wrapUser = (WrapUser) httpSession.getAttribute("wrapUserSession");
		if (wrapUser == null) {
			String username = (String) httpSession.getAttribute("username");
			wrapUser = wrapUtil.getLoggedInUserInfo(username);
		}
		model.addAttribute("wrapUser", wrapUser);
		
		List<WrapProduct> WrapProductList = wrapProductDaoImpl.getAllWrapProducts();
		model.addAttribute("WrapProductList", WrapProductList);

		return new ModelAndView("prod-itm-management");
	}
	
}
