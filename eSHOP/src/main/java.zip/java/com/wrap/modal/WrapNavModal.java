package com.wrap.modal;

import java.util.List;

public class WrapNavModal {
	private List<WrapNavTab> wrapNavTabList;

	public WrapNavModal() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the wrapNavTabList
	 */
	public List<WrapNavTab> getWrapNavTabList() {
		return wrapNavTabList;
	}

	/**
	 * @param wrapNavTabList
	 *            the wrapNavTabList to set
	 */
	public void setWrapNavTabList(List<WrapNavTab> wrapNavTabList) {
		this.wrapNavTabList = wrapNavTabList;
	}

}
