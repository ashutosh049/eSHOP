/**
 * 
 */
package com.wrap.modal;

/**
 * DESCRIPTION GOES HERE<br>
 * <br>
 * Copyright (c) 2016 kumar.ashutosh@skillnetinc.com
 *
 * @author ashu
 * @created Oct 19, 2016
 * @version $Revision$
 */
public class WrapUserCard {

	private String userName;
	private String userCCId;
	private String ccType;
	private String ccNumber;
	private String ccOnName;
	private String ccExpirationMonth;
	private String ccExpirationYear;
	private String ccCvvNumber;
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return the userCCId
	 */
	public String getUserCCId() {
		return userCCId;
	}
	/**
	 * @param userCCId the userCCId to set
	 */
	public void setUserCCId(String userCCId) {
		this.userCCId = userCCId;
	}
	/**
	 * @return the ccType
	 */
	public String getCcType() {
		return ccType;
	}
	/**
	 * @param ccType the ccType to set
	 */
	public void setCcType(String ccType) {
		this.ccType = ccType;
	}
	/**
	 * @return the ccNumber
	 */
	public String getCcNumber() {
		return ccNumber;
	}
	/**
	 * @param ccNumber the ccNumber to set
	 */
	public void setCcNumber(String ccNumber) {
		this.ccNumber = ccNumber;
	}
	/**
	 * @return the ccOnName
	 */
	public String getCcOnName() {
		return ccOnName;
	}
	/**
	 * @param ccOnName the ccOnName to set
	 */
	public void setCcOnName(String ccOnName) {
		this.ccOnName = ccOnName;
	}
	/**
	 * @return the ccExpirationMonth
	 */
	public String getCcExpirationMonth() {
		return ccExpirationMonth;
	}
	/**
	 * @param ccExpirationMonth the ccExpirationMonth to set
	 */
	public void setCcExpirationMonth(String ccExpirationMonth) {
		this.ccExpirationMonth = ccExpirationMonth;
	}
	/**
	 * @return the ccExpirationYear
	 */
	public String getCcExpirationYear() {
		return ccExpirationYear;
	}
	/**
	 * @param ccExpirationYear the ccExpirationYear to set
	 */
	public void setCcExpirationYear(String ccExpirationYear) {
		this.ccExpirationYear = ccExpirationYear;
	}
	/**
	 * @return the ccCvvNumber
	 */
	public String getCcCvvNumber() {
		return ccCvvNumber;
	}
	/**
	 * @param ccCvvNumber the ccCvvNumber to set
	 */
	public void setCcCvvNumber(String ccCvvNumber) {
		this.ccCvvNumber = ccCvvNumber;
	}
	
		
}
