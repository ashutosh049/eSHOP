--WRAPTAB_1
INSERT INTO wrapit.wrap_column(wrapTabId,wrapColId,wrapColName,wrapColSortOrder)
VALUES("WRAPTAB_1","WRAPCOL_1","Clothing",10);
INSERT INTO wrapit.wrap_column(wrapTabId,wrapColId,wrapColName,wrapColSortOrder)
VALUES("WRAPTAB_1","WRAPCOL_2","Footwear",20);
INSERT INTO wrapit.wrap_column(wrapTabId,wrapColId,wrapColName,wrapColSortOrder)
VALUES("WRAPTAB_1","WRAPCOL_3","Watches",30);

--WRAPTAB_2
INSERT INTO wrapit.wrap_column(wrapTabId,wrapColId,wrapColName,wrapColSortOrder)
VALUES("WRAPTAB_2","WRAPCOL_1","Laptops",10);
INSERT INTO wrapit.wrap_column(wrapTabId,wrapColId,wrapColName,wrapColSortOrder)
VALUES("WRAPTAB_2","WRAPCOL_2","Mobiles",20);
INSERT INTO wrapit.wrap_column(wrapTabId,wrapColId,wrapColName,wrapColSortOrder)
VALUES("WRAPTAB_2","WRAPCOL_3","TV",30);

--WRAPTAB_3
INSERT INTO wrapit.wrap_column(wrapTabId,wrapColId,wrapColName,wrapColSortOrder)
VALUES("WRAPTAB_3","WRAPCOL_1","Books",10);
INSERT INTO wrapit.wrap_column(wrapTabId,wrapColId,wrapColName,wrapColSortOrder)
VALUES("WRAPTAB_3","WRAPCOL_2","Gaming",20);
INSERT INTO wrapit.wrap_column(wrapTabId,wrapColId,wrapColName,wrapColSortOrder)
VALUES("WRAPTAB_3","WRAPCOL_3","Stationary",30);

--WRAPTAB_4
INSERT INTO wrapit.wrap_column(wrapTabId,wrapColId,wrapColName,wrapColSortOrder)
VALUES("WRAPTAB_4","WRAPCOL_1","Furniture",10);
INSERT INTO wrapit.wrap_column(wrapTabId,wrapColId,wrapColName,wrapColSortOrder)
VALUES("WRAPTAB_4","WRAPCOL_2","Home Decor",20);
INSERT INTO wrapit.wrap_column(wrapTabId,wrapColId,wrapColName,wrapColSortOrder)
VALUES("WRAPTAB_4","WRAPCOL_3","Kitcher & Dining",30);




