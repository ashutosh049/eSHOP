INSERT INTO wrap_tab(wrapTabId,wrapTabName,wrapTabSortOrder)
VALUES("WRAPTAB_1","Trending",10);

INSERT INTO wrap_tab(wrapTabId,wrapTabName,wrapTabSortOrder)
VALUES("WRAPTAB_2","Featured",20);

INSERT INTO wrap_tab(wrapTabId,wrapTabName,wrapTabSortOrder)
VALUES("WRAPTAB_3","Books & More",30);

INSERT INTO wrap_tab(wrapTabId,wrapTabName,wrapTabSortOrder)
VALUES("WRAPTAB_4","Home & Furniture",40);


