/**
 * 
 */
package com.wrap.modal;

/**
 * @author ashu
 * 
 */
public class WrapNavCat {
	private WrapCategory wrapCategory;

	public WrapNavCat() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the wrapCategory
	 */
	public WrapCategory getWrapCategory() {
		return wrapCategory;
	}

	/**
	 * @param wrapCategory
	 *            the wrapCategory to set
	 */
	public void setWrapCategory(WrapCategory wrapCategory) {
		this.wrapCategory = wrapCategory;
	}

}
